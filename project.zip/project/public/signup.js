document.addEventListener("DOMContentLoaded", function () {
    const signupForm = document.getElementById("signupForm");
    const userType = document.getElementById("userType");
    const dynamicLabel = document.getElementById("dynamicLabel");
    const dynamicId = document.getElementById("dynamicId");

    userType.addEventListener("change", function () {
        if (userType.value === "admin") {
            dynamicLabel.textContent = "Admin ID:";
            dynamicId.placeholder = "Enter Admin ID";
        } else {
            dynamicLabel.textContent = "Student ID:";
            dynamicId.placeholder = "Enter Student ID";
        }
    });

    signupForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const userTypeValue = userType.value;
        const userId = dynamicId.value.trim();
        const firstName = document.getElementById("firstName").value.trim();
        const lastName = document.getElementById("lastName").value.trim();
        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value.trim();
        const confirmPassword = document.getElementById("confirmPassword").value.trim();

        if (!userId || !firstName || !lastName || !email || !password || !confirmPassword) {
            alert("All fields are required!");
            return;
        }

        if (!/^[a-zA-Z0-9]+$/.test(userId)) {
            alert(`${userTypeValue === "admin" ? "Admin" : "Student"} ID must contain only letters and numbers!`);
            return;
        }

        if (password.length < 6) {
            alert("Password must be at least 6 characters long!");
            return;
        }

        if (password !== confirmPassword) {
            alert("Passwords do not match!");
            return;
        }

        if (!validateEmail(email)) {
            alert("Please enter a valid email address!");
            return;
        }

        sessionStorage.setItem("userData", JSON.stringify({
            userType: userTypeValue,
            name: firstName + " " + lastName,
            userId,
            firstName,
            lastName,
            email,
            password
        }));

        window.location.href = "otp.html";
    });

    function validateEmail(email) {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailPattern.test(email);
    }
});