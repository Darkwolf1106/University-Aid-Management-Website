(function OTP() {
    emailjs.init("MEC-pLOtJQAD2etrg"); // Ensure correct EmailJS user ID
})();

let generatedOtp = "";

// Handle OTP sending
document.getElementById("sendOtpButton").addEventListener("click", function () {
    const email = document.getElementById("email").value;

    if (!email) {
        alert("Please enter a valid email address.");
        return;
    }

    generatedOtp = Math.floor(100000 + Math.random() * 900000).toString();

    emailjs.send("service_jrfi2nj", "template_mdobcx8", {
        to_email: email,
        message: `Your OTP code is: ${generatedOtp}`,
    }).then(
        function (response) {
            console.log("SUCCESS!", response.status, response.text);
            alert("OTP sent successfully!");
            document.getElementById("otpSection").style.display = "block";
        },
        function (error) {
            console.log("FAILED...", error);
            alert("Failed to send OTP. Please try again.");
        }
    );
});

// Handle OTP verification and redirection
document.getElementById("otpForm").addEventListener("submit", function (event) {
    event.preventDefault();

    const enteredOtp = document.getElementById("otp").value;

    if (enteredOtp === generatedOtp) {
        alert("OTP verified successfully!");
        setTimeout(() => {
            window.location.href = "password_recovery.html"; 
        }, 1500); // Redirect after 1.5 seconds for better UX
    } else {
        alert("Invalid OTP. Please try again.");
    }
});