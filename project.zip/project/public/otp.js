(function OTP() {
    emailjs.init("MEC-pLOtJQAD2etrg"); // Ensure correct EmailJS user ID
})();


let generatedOtp = "";


// Handle OTP sending
document.getElementById("sendOtpButton").addEventListener("click", function () {
    const email = document.getElementById("email").value;

    if (!email) {
        alert("Please enter a valid email address.");
        return;
    }

    generatedOtp = Math.floor(100000 + Math.random() * 900000).toString();

    emailjs.send("service_jrfi2nj", "template_mdobcx8", {
        to_email: email,
        message: `Your OTP code is: ${generatedOtp}`,
    }).then(
        function (response) {
            console.log("SUCCESS!", response.status, response.text);
            alert("OTP sent successfully!");
            document.getElementById("otpSection").style.display = "block";
        },
        function (error) {
            console.log("FAILED...", error);
            alert("Failed to send OTP. Please try again.");
        }
    );
});



// Handle OTP verification and save user details
document.getElementById("otpForm").addEventListener("submit", function (event) {
    event.preventDefault();

    const enteredOtp = document.getElementById("otp").value;

    if (enteredOtp === generatedOtp) {
        alert("OTP verified successfully!");

        const userData = JSON.parse(sessionStorage.getItem("userData"));
        if (userData) {
            fetch("/signup", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(userData),
            })
            .then(async response => {
                const result = await response.json();
                if (response.ok) {
                    alert(result.message);
                    sessionStorage.removeItem("userData");
                    window.location.href = "login.html"; // Redirect to login after success
                } else {
                    alert(result.message);
                }
            })
            .catch(error => {
                console.error("Error:", error);
                alert("An unexpected error occurred. Please try again.");
            });
        }
    } else {
        alert("Invalid OTP. Please try again.");
    }
});