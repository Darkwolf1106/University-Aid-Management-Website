
// Display Accepted Students
const populateStudentTable = () => {
  fetch('/get-accepted-students')
      .then(response => response.json())
      .then(data => {
          console.log("Fetched accepted students:", data); // Debugging
          const tbody = document.querySelector("#students-table tbody");
          tbody.innerHTML = "";

          if (data.length === 0) {
              tbody.innerHTML = "<tr><td colspan='5'>No accepted students found</td></tr>";
              return;
          }

          data.forEach(student => {
              const row = document.createElement("tr");
              row.innerHTML = `
                  <td>${student.name}</td>
                  <td>${student.student_id}</td>
                  <td>${student.status}</td>
                  <td>${student.aid_type}</td>
                  <td>RM ${parseInt(student.aid_amount || 0).toLocaleString()}</td>
              `;
              tbody.appendChild(row);
          });
      })
      .catch(error => console.error('Error fetching accepted students:', error));
}


// Initialize the Page
document.addEventListener("DOMContentLoaded", () => {
  populateStudentTable();
  populateStudentDropdown();
  handleAidAdjustment();
});
 


// Populate the Dropdown
const populateStudentDropdown = () => {
  fetch('/get-accepted-students')
      .then(response => response.json())
      .then(data => {
          const studentSelect = document.querySelector("#student-select");
          studentSelect.innerHTML = "";

          // Default option
          const defaultOption = document.createElement("option");
          defaultOption.value = "";
          defaultOption.textContent = "Select a Student";
          defaultOption.disabled = true;
          defaultOption.selected = true;
          studentSelect.appendChild(defaultOption);

          // Populate student options
          data.forEach((student) => {
              const option = document.createElement("option");
              option.value = student.student_id;
              option.textContent = `${student.name} (${student.aid_type})`;
              studentSelect.appendChild(option);
          });
      })
      .catch(error => console.error('Error fetching students for dropdown:', error));
};


// Update Bugeting
const updateBudgetDisplay = () => {
  fetch('/get-budget-info')
      .then(response => response.json())
      .then(data => {
        document.querySelector("#total-budget").textContent = `RM${data.totalBudget.toLocaleString()}`;
        document.querySelector("#remaining-budget").textContent = `RM${data.remainingBudget.toLocaleString()}`;
      })
      .catch(error => console.error('Error fetching budget data:', error));
};



// Call this function after updating aid amount
document.addEventListener("DOMContentLoaded", () => {
    updateBudgetDisplay(); // Fetch budget initially
});


// Aid amount adjustment  
const handleAidAdjustment = () => {
  const studentSelect = document.querySelector("#student-select");
  const aidAmountInput = document.querySelector("#aid-amount");

  document.querySelector("#apply-aid").addEventListener("click", () => {
      const selectedStudentId = studentSelect.value;
      const newAidAmount = parseInt(aidAmountInput.value || 0);

      if (!selectedStudentId) {
          alert("Please select a student to adjust aid.");
          return;
      }

      fetch('/update-aid-amount', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ student_id: selectedStudentId, aid_amount: newAidAmount })
      })
      .then(response => response.json())
      .then(data => {
          populateStudentTable(); // Refresh table with updated data
          updateBudgetDisplay(); 
      })
      .catch(error => console.error('Error updating aid amount:', error));
  });
};



// Initialize the Page
document.addEventListener("DOMContentLoaded", () => {
  populateStudentTable();
  populateStudentDropdown();
  handleAidAdjustment();
});

  
// Update aid amount display in real-time
aidAmountInput.addEventListener("input", () => {
  aidAmountDisplay.textContent = `RM${parseInt(aidAmountInput.value || 0).toLocaleString()}`;
});



// Apply Aid Button Click
document.querySelector("#apply-aid").addEventListener("click", () => {
  const selectedStudentId = parseInt(studentSelect.value);

  if (!selectedStudentId) {
    alert("Please select a student to adjust aid.");
    return;
  }

  const selectedStudent = students.find((student) => student.id === selectedStudentId);

  if (selectedStudent) {
    const newAidAmount = parseInt(aidAmountInput.value || 0);
    selectedStudent.aidAmount = newAidAmount;

    // Update the table dynamically
    const studentRow = document.querySelector(
      `#students-table tbody tr[data-student-id="${selectedStudentId}"]`
    );
    studentRow.querySelector("td:last-child").textContent = `$${newAidAmount.toLocaleString()}`;

    alert(`Aid amount for ${selectedStudent.name} has been updated to $${newAidAmount.toLocaleString()}.`);
  }
});
  
  
// Initialize the Page
document.addEventListener("DOMContentLoaded", () => {
  populateStudentTable();
  populateStudentDropdown();
  handleAidAdjustment();
});


  