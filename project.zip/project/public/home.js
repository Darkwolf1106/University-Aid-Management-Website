// Handle application form submission
document.getElementById('application-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const applicationDetails = document.getElementById('application-details').value;

    if(applicationDetails) {
        alert('Application Submitted Successfully!');
        document.getElementById('application-details').value = ''; // Clear the form
    }
});



// Handle track status form submission
document.getElementById('track-status-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const applicationNumber = document.getElementById('application-number').value;

    if(applicationNumber) {
        alert('Checking application status for: ' + applicationNumber);
    }
});



// Handle appeal form submission
document.getElementById('appeal-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const appealReason = document.getElementById('appeal-reason').value;

    if(appealReason) {
        alert('Appeal Submitted Successfully!');
        document.getElementById('appeal-reason').value = ''; // Clear the form
    }
});