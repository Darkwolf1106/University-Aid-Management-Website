function openModal() {
    const aidType = document.getElementById('aid-type').value;
    if (!aidType) {
        alert('Please select an aid type.');
        return;
    }
    const meritForm = document.getElementById('merit-form');
    const needForm = document.getElementById('need-form');
    if (aidType === 'merit-scholarship') {
        meritForm.style.display = 'block';
        needForm.style.display = 'none';
    } else if (aidType === 'need-based-scholarship') {
        needForm.style.display = 'block';
        meritForm.style.display = 'none';
    }
    document.getElementById('applicationModal').style.display = 'block';
}



function closeModal() {
    document.getElementById('applicationModal').style.display = 'none';
}



function submitApplication(type) {
    let formData = new FormData();
    let endpoint = '';

    if (type === 'merit') {
        const name = document.getElementById('student-name').value;
        const studentId = document.getElementById('student-id').value;
        const program = document.getElementById('program').value;
        const achievements = document.getElementById('achievements').value;
        const academicRecord = document.getElementById('academic-record').files[0];

        if (!name || !studentId || !program || !achievements || !academicRecord) {
            alert('All fields are required.');
            return;
        }

        formData.append('name', name);
        formData.append('studentId', studentId);
        formData.append('program', program);
        formData.append('achievements', achievements);
        formData.append('academicRecord', academicRecord);
        
        endpoint = '/register-merit';
    } else if (type === 'need') {
        const name = document.getElementById('student-name-need').value;
        const studentId = document.getElementById('student-id-need').value;
        const householdIncome = document.getElementById('household-income').value;
        const financialDocuments = document.getElementById('financial-documents').files[0];

        if (!name || !studentId || !householdIncome || !financialDocuments) {
            alert('All fields are required.');
            return;
        }

        formData.append('name', name);
        formData.append('studentId', studentId);
        formData.append('householdIncome', householdIncome);
        formData.append('financialDocuments', financialDocuments);

        const dependents = [];
        document.querySelectorAll('.dependents-table tbody tr').forEach(row => {
            const name = row.cells[0].querySelector('input').value;
            const relationship = row.cells[1].querySelector('input').value;
            const age = row.cells[2].querySelector('input').value;
            const occupation = row.cells[3].querySelector('input').value;
            if (name && relationship && age && occupation) {
                dependents.push({ name, relationship, age, occupation });
            }
        });

        formData.append('dependents', JSON.stringify(dependents));
        endpoint = '/register-needbased';
    }

    fetch(endpoint, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        closeModal();
    })
    .catch(error => {
        alert('Error submitting application.');
        console.error('Error:', error);
    });
}



function viewAidInfo() {
    const aidType = document.getElementById('aid-info').value;
    if (!aidType) {
        alert('Please select an aid type.');
        return;
    }

    const content = document.getElementById('aid-info-content');
    let description = '';
    let tableHtml = '<table><thead><tr><th>Category</th><th>Details</th></tr></thead><tbody>';

    if (aidType === 'merit-scholarship') {
        description = `
            <p>The <strong>Merit Scholarship</strong> is awarded to students who demonstrate exceptional academic performance, leadership skills, and achievements in extracurricular activities. This scholarship is designed to recognize and reward outstanding scholars.</p>
        `;
        tableHtml += `
            <tr><td><strong>Eligibility</strong></td><td>Minimum GPA: 3.5, Academic Excellence, Extracurricular Achievements</td></tr>
            <tr><td><strong>Award Details</strong></td><td>Full/Partial Tuition Waiver, One-time Grant</td></tr>
            <tr><td><strong>Required Documents</strong></td><td>Academic Transcripts, Recommendation Letters, Statement of Purpose</td></tr>
            <tr><td><strong>Deadline</strong></td><td>June 30, 2025</td></tr>
        `;
    } else if (aidType === 'need-based-scholarship') {
        description = `
            <p>The <strong>Need-Based Scholarship</strong> is designed to assist students facing financial challenges in pursuing their education. This aid is granted based on the financial situation of the student and their family.</p>
        `;
        tableHtml += `
            <tr><td><strong>Eligibility</strong></td><td>Household Income below $50,000/year, Financial Hardship Documentation</td></tr>
            <tr><td><strong>Award Details</strong></td><td>Monthly Stipend: $500, Tuition Reduction up to 50%</td></tr>
            <tr><td><strong>Required Documents</strong></td><td>Income Certificate, Proof of Dependents</td></tr>
            <tr><td><strong>Deadline</strong></td><td>July 15, 2025</td></tr>
        `;
    }

    tableHtml += '</tbody></table>';
    content.innerHTML = description + tableHtml;

    document.getElementById('aidInfoModal').style.display = 'block';
}



function closeAidInfoModal() {
    document.getElementById('aidInfoModal').style.display = 'none';
}



function submitAppeal() {
    const name = document.getElementById('appeal-name').value;
    const studentId = document.getElementById('appeal-student-id').value;
    const aidType = document.getElementById('appeal-aid-type').value;
    const reasonRejection = document.getElementById('appeal-reason-rejection').value;
    const reasonAppeal = document.getElementById('appeal-reason').value;
    const appealDocs = document.getElementById('appeal-docs').files[0];

    if (!name || !studentId || !aidType || !reasonRejection || !reasonAppeal || !appealDocs) {
        alert('All fields are required.');
        return;
    }

    const formData = new FormData();
    formData.append('name', name);
    formData.append('studentId', studentId);
    formData.append('aidType', aidType);
    formData.append('reasonRejection', reasonRejection);
    formData.append('reasonAppeal', reasonAppeal);
    formData.append('appealDocs', appealDocs);

    fetch('/submit-appeal', {
        method: 'POST',
        body: formData,
    })
        .then(response => response.json())
        .then(data => alert(data.message))
        .catch(error => console.error('Error:', error));
}



function openAppealModal() {
    document.getElementById('appealModal').style.display = 'block';
}



function closeAppealModal() {
    document.getElementById('appealModal').style.display = 'none';
}

function fetchApplicationStatus() {
    const userId = document.getElementById('user-id-status').value.trim();

    if (!userId) {
        alert("Please enter your User ID.");
        return;
    }

    fetch(`/get-application-status/${userId}`)
        .then(response => response.json())
        .then(data => {
            const statusText = document.getElementById('status-text');
            const statusBar = document.getElementById('status-bar');

            if (data.status) {
                statusText.innerHTML = `<strong>Aid Type:</strong> ${data.aid_type} <br> <strong>Status:</strong> ${data.status}`;

                // Mapping statuses to colors
                const statusColors = {
                    "pending": "#FFD700", // Yellow
                    "under_review": "#FFA500", // Orange
                    "additional_documents_required": "#800080", // Purple
                    "decision_pending": "#1E90FF", // Blue
                    "approved": "#008000", // Green
                    "denied": "#FF0000" // Red
                };

                // Set the color dynamically
                statusBar.style.backgroundColor = statusColors[data.status] || "#808080"; // Default to Gray if unknown status
                statusBar.style.width = "100%";
            } else {
                statusText.innerHTML = "No application found for this User ID.";
                statusBar.style.backgroundColor = "#808080"; // Gray for no data
                statusBar.style.width = "0%";
            }
        })
        .catch(error => {
            console.error("Error fetching application status:", error);
            alert("Failed to fetch application status.");
        });
}