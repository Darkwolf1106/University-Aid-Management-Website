document.addEventListener("DOMContentLoaded", function () {
    const recoveryForm = document.getElementById('recoveryForm');
    const messageBox = document.getElementById('recoveryMessage');

    recoveryForm.addEventListener('submit', async function (event) {
        event.preventDefault(); // Prevent page refresh

        const email = document.getElementById('email').value.trim();
        const newPassword = document.getElementById('new-password').value.trim();
        const confirmPassword = document.getElementById('confirm-password').value.trim();

        // Input validation
        if (!email || !newPassword || !confirmPassword) {
            messageBox.textContent = "All fields are required.";
            messageBox.style.color = "red";
            return;
        }

        if (newPassword !== confirmPassword) {
            messageBox.textContent = "Passwords do not match.";
            messageBox.style.color = "red";
            return;
        }

        try {
            const response = await fetch('/password-recovery', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, newPassword })
            });

            const data = await response.json();
            messageBox.textContent = data.message;

            if (response.ok) {
                messageBox.style.color = "green";
                recoveryForm.reset(); // Clear input fields on success
            } else {
                messageBox.style.color = "red";
            }
        } catch (error) {
            console.error("Error:", error);
            messageBox.textContent = "Error connecting to the server.";
            messageBox.style.color = "red";
        }
    });
});
