document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value;

    // Validate input fields
    if (!email || !password || !role) {
        alert("Please fill in all fields!");
        return;
    }

    // Validate email format
    if (!validateEmail(email)) {
        alert("Please enter a valid email address!");
        return;
    }

    try {
        const response = await fetch('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password, role }),
        });

        const result = await response.json();
        
        const loginMessage = document.getElementById('loginMessage');
        if (response.ok) {
            loginMessage.style.color = 'green';
            loginMessage.textContent = 'Login successful! Redirecting...';
            setTimeout(() => {
                if (role === 'student') {
                    window.location.href = './home.html';  // Redirect for students
                } else if (role === 'admin') {
                    window.location.href = './adminhome.html';  // Redirect for admins
                }
            }, 2000);
        } else {
            loginMessage.style.color = 'red';
            loginMessage.textContent = 'Login failed. Please try again.';
        }
    } catch (error) {
        console.error('Error during login:', error);
        alert('An error occurred. Please try again.');
    }
});



// Function to validate email format
function validateEmail(email) {
    let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
}