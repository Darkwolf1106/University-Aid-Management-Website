document.addEventListener("DOMContentLoaded", function () {
    fetchMeritScholarships();
    fetchNeedBasedScholarships();
});



// Fetch Merit Scholarships and populate table
function fetchMeritScholarships() {
    fetch('/get-merit-scholarships')
        .then(response => response.json())
        .then(data => {
            const tableBody = document.querySelector("#merit-scholarship-table tbody");
            tableBody.innerHTML = ""; // Clear existing rows

            data.forEach(row => {
                const tr = document.createElement("tr");
                tr.innerHTML = `
                    <td>${row.id}</td>
                    <td>${row.name}</td>
                    <td>${row.student_id}</td>
                    <td>${row.program}</td>
                    <td>${row.achievements}</td>
                    <td><a href="/uploads/${row.academic_record}" target="_blank">View</a></td>
                    <td>
                        <select class="status-dropdown" data-id="${row.id}">
                            <option value="under_review" ${row.status === "under_review" ? "selected" : ""}>Under Review</option>
                            <option value="additional_documents_required" ${row.status === "additional_documents_required" ? "selected" : ""}>Additional Documents Required</option>
                            <option value="decision_pending" ${row.status === "decision_pending" ? "selected" : ""}>Decision Pending</option>
                            <option value="approved" ${row.status === "approved" ? "selected" : ""}>Approved</option>
                            <option value="denied" ${row.status === "denied" ? "selected" : ""}>Denied</option>
                        </select>
                    </td>
                `;
                tableBody.appendChild(tr);
            });
        })
        .catch(error => console.error("Error fetching merit scholarships:", error));
}



// Fetch Need-Based Scholarships and populate table
function fetchNeedBasedScholarships() {
    fetch('/get-needbased-scholarships')
        .then(response => response.json())
        .then(data => {
            const tableBody = document.querySelector("#needbased-scholarship-table tbody");
            tableBody.innerHTML = ""; // Clear existing rows

            data.forEach(row => {
                const tr = document.createElement("tr");
                tr.innerHTML = `
                    <td>${row.id}</td>
                    <td>${row.name}</td>
                    <td>${row.student_id}</td>
                    <td>RM ${row.household_income.toFixed(2)}</td>
                    <td><a href="/uploads/${row.financial_documents}" target="_blank">View</a></td>
                    <td>
                        <select class="status-dropdown" data-id="${row.id}">
                            <option value="under_review" ${row.status === "under_review" ? "selected" : ""}>Under Review</option>
                            <option value="additional_documents_required" ${row.status === "additional_documents_required" ? "selected" : ""}>Additional Documents Required</option>
                            <option value="decision_pending" ${row.status === "decision_pending" ? "selected" : ""}>Decision Pending</option>
                            <option value="approved" ${row.status === "approved" ? "selected" : ""}>Approved</option>
                            <option value="denied" ${row.status === "denied" ? "selected" : ""}>Denied</option>
                        </select>
                    </td>
                `;
                tableBody.appendChild(tr);
            });
        })
        .catch(error => console.error("Error fetching need-based scholarships:", error));
}



// Listen for changes in status dropdown and send updates to the server
document.addEventListener("change", function (event) {
    if (event.target.classList.contains("status-dropdown")) {
        const scholarshipId = event.target.getAttribute("data-id");
        const newStatus = event.target.value;

        // Determine the scholarship type based on the table
        const tableElement = event.target.closest("table");
        const scholarshipType = tableElement.id === "merit-scholarship-table" ? "merit" : "needbased";

        fetch("/update-status", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ id: scholarshipId, status: newStatus, type: scholarshipType })
        })
        .then(response => response.json())
        .then(data => console.log(data.message))
        .catch(error => console.error("Error updating status:", error));
    }
});



// Fetch all dependents and display them
function fetchAllDependents() {
    fetch('/get-all-dependents')
        .then(response => response.json())
        .then(data => {
            const tableBody = document.querySelector("#dependents-table tbody");
            tableBody.innerHTML = ""; // Clear existing rows

            if (data.length === 0) {
                tableBody.innerHTML = "<tr><td colspan='5'>No dependents found.</td></tr>";
            } else {
                data.forEach(dependent => {
                    const tr = document.createElement("tr");
                    tr.innerHTML = `
                        <td>${dependent.student_id}</td>
                        <td>${dependent.name}</td>
                        <td>${dependent.relationship}</td>
                        <td>${dependent.age}</td>
                        <td>${dependent.occupation}</td>
                    `;
                    tableBody.appendChild(tr);
                });
            }
        })
        .catch(error => console.error("Error fetching all dependents:", error));
}



// Call fetchAllDependents when the page loads
document.addEventListener("DOMContentLoaded", function () {
    fetchMeritScholarships();
    fetchNeedBasedScholarships();
    fetchAllDependents(); // Fetch and display all dependents
});




// Function to update the dropdown background color
function updateDropdownColor(selectElement) {
    const statusColors = {
        "under_review": "#FFE5CC",  // Yellow
        "additional_documents_required": "#CCCCFF",  // Orange
        "decision_pending": "#CCE5FF",  // Cyan
        "approved": "#CCFFCC",  // Green
        "denied": "#FFCCCC"  // Red
    };

    selectElement.style.backgroundColor = statusColors[selectElement.value] || "#ffffff"; // Default to white
}



// Apply colors when the page loads
document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".status-dropdown").forEach(select => {
        updateDropdownColor(select);
    });
});



// Update color on change
document.addEventListener("change", function (event) {
    if (event.target.classList.contains("status-dropdown")) {
        updateDropdownColor(event.target);
    }
});