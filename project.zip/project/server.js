const express = require('express');
const multer = require('multer');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const path = require('path');
const cors = require('cors');
const fs = require('fs');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static('/Users/tharunnesh/Documents/Software_Eng_Fundamentals/uploads'));

// Ensure upload directory exists
const uploadDir = 'uploads';
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

const storage = multer.diskStorage({
    destination: uploadDir,
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    },
});

const upload = multer({ storage });

// Single database connection
const db = new sqlite3.Database('unified_database.db', (err) => {
    if (err) {
        console.error('Error opening database:', err.message);
    } else {
        console.log('Connected to SQLite database.');

        db.run(`
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                user_id TEXT UNIQUE,
                first_name TEXT,
                last_name TEXT,
                email TEXT UNIQUE,
                password TEXT
            )
        `);

        db.run(`
            CREATE TABLE IF NOT EXISTS admins (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                user_id TEXT UNIQUE,
                first_name TEXT,
                last_name TEXT,
                email TEXT UNIQUE,
                password TEXT
            )
        `);

        db.run(`
            CREATE TABLE IF NOT EXISTS meritscholarship (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                student_id TEXT UNIQUE,
                program TEXT,
                achievements TEXT,
                academic_record TEXT,
                status TEXT DEFAULT 'under_review',
                aid_type TEXT DEFAULT 'merit-scholarship'
            )
        `);
        
        db.run(`
            CREATE TABLE IF NOT EXISTS needbasedscholarship (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                student_id TEXT UNIQUE,
                household_income REAL,
                financial_documents TEXT,
                status TEXT DEFAULT 'under_review',
                aid_type TEXT DEFAULT 'need-based-scholarship'
            )
        `);

        db.run(`
            CREATE TABLE IF NOT EXISTS dependentsneedbasedscholarship (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id TEXT,
                name TEXT,
                relationship TEXT,
                age INTEGER,
                occupation TEXT,
                FOREIGN KEY(student_id) REFERENCES needbasedscholarship(student_id)
            )
        `);

        db.run(`
            CREATE TABLE IF NOT EXISTS appeal_decision (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                student_id TEXT,
                aid_type TEXT,
                reason_rejection TEXT,
                reason_appeal TEXT,
                appeal_docs TEXT,
                status TEXT DEFAULT 'pending'
            )
        `);

        db.run(`
            CREATE TABLE IF NOT EXISTS accepted__students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                student_id TEXT UNIQUE,
                status TEXT,
                aid_type TEXT,
                aid_amount INTEGER DEFAULT '0'
            )
        `);

     

    }
});

// Serve different pages dynamically
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'profile.html'));
});

app.get('/application', (req, res) => {
    res.sendFile(path.join(__dirname, 'application.html'));
});

// Signup Route
app.post('/signup', (req, res) => {
    const { userType, name, userId, firstName, lastName, email, password } = req.body;
    const table = userType === 'student' ? 'students' : 'admins';

    const query = `INSERT INTO ${table} (name, user_id, first_name, last_name, email, password) VALUES (?, ?, ?, ?, ?, ?)`;

    db.run(query, [name, userId, firstName, lastName, email, password], function (err) {
        if (err) {
            console.error('Error inserting data:', err.message);
            return res.status(500).json({ message: 'Database error: ' + err.message });
        }
        res.json({ message: 'Sign up successful' });
    });
});

// Login Route
app.post('/login', (req, res) => {
    const { email, password, role } = req.body;
    const table = role === 'student' ? 'students' : 'admins';

    const query = `SELECT * FROM ${table} WHERE email = ? AND password = ?`;
    db.get(query, [email, password], (err, row) => {
        if (err) {
            return res.status(500).json({ message: 'Database error' });
        }
        if (row) {
            return res.json({ message: 'Login successful' });
        } else {
            return res.status(401).json({ message: 'Login failed' });
        }
    });
});


// Password Recovery Route
app.post('/password-recovery', (req, res) => {
    const { email, newPassword } = req.body;

    if (!email || !newPassword) {
        return res.status(400).json({ message: 'Email and new password are required.' });
    }

    // Check if email exists in students table
    db.get('SELECT email FROM students WHERE email = ?', [email], (err, studentRow) => {
        if (err) {
            console.error('Database error (students):', err.message);
            return res.status(500).json({ message: 'Database error.' });
        }

        if (studentRow) {
            // Update password in students table
            db.run('UPDATE students SET password = ? WHERE email = ?', [newPassword, email], function (err) {
                if (err) {
                    console.error('Error updating student password:', err.message);
                    return res.status(500).json({ message: 'Failed to update password.' });
                }
                return res.json({ message: 'Password updated successfully for student.' });
            });
        } else {
            // Check if email exists in admins table
            db.get('SELECT email FROM admins WHERE email = ?', [email], (err, adminRow) => {
                if (err) {
                    console.error('Database error (admins):', err.message);
                    return res.status(500).json({ message: 'Database error.' });
                }

                if (adminRow) {
                    // Update password in admins table
                    db.run('UPDATE admins SET password = ? WHERE email = ?', [newPassword, email], function (err) {
                        if (err) {
                            console.error('Error updating admin password:', err.message);
                            return res.status(500).json({ message: 'Failed to update password.' });
                        }
                        return res.json({ message: 'Password updated successfully for admin.' });
                    });
                } else {
                    console.log('Email not found:', email);
                    return res.status(404).json({ message: 'Email not found.' });
                }
            });
        }
    });
});


// Retrieve user details (Students)
app.get('/get-user/:userId', (req, res) => {
    const { userId } = req.params;

    db.get('SELECT * FROM students WHERE user_id = ?', [userId], (err, row) => {
        if (err) {
            res.status(500).json({ error: 'Database error.' });
            return;
        }
        if (!row) {
            res.status(404).json({ error: 'User not found.' });
            return;
        }
        res.json(row);
    });
});

// Update user details (students)
app.post('/update-user', (req, res) => {
    const { userId, firstName, lastName, email, password } = req.body;

    if (!userId || !firstName || !lastName || !email || !password) {
        return res.status(400).json({ message: 'All fields are required.' });
    }

    db.run(
        `UPDATE students SET first_name = ?, last_name = ?, email = ?, password = ? WHERE user_id = ?`,
        [firstName, lastName, email, password, userId],
        function (err) {
            if (err) {
                console.error('Error updating user:', err.message);
                return res.status(500).json({ message: 'Failed to update user details.' });
            }
            if (this.changes === 0) {
                return res.status(404).json({ message: 'User not found or no changes made.' });
            }
            res.json({ message: 'User details updated successfully!' });
        }
    );
});

// Retrieve admin details
app.get('/get-admin/:adminId', (req, res) => {
    const { adminId } = req.params;

    db.get('SELECT * FROM admins WHERE user_id = ?', [adminId], (err, row) => {
        if (err) {
            res.status(500).json({ error: 'Database error.' });
            return;
        }
        if (!row) {
            res.status(404).json({ error: 'Admin not found.' });
            return;
        }
        res.json(row);
    });
});

// Update admin details
app.post('/update-admin', (req, res) => {
    const { adminId, firstName, lastName, email, password } = req.body;

    if (!adminId || !firstName || !lastName || !email || !password) {
        return res.status(400).json({ message: 'All fields are required.' });
    }

    db.run(
        `UPDATE admins SET first_name = ?, last_name = ?, email = ?, password = ? WHERE user_id = ?`,
        [firstName, lastName, email, password, adminId],
        function (err) {
            if (err) {
                console.error('Error updating admin:', err.message);
                return res.status(500).json({ message: 'Failed to update admin details.' });
            }
            if (this.changes === 0) {
                return res.status(404).json({ message: 'Admin not found or no changes made.' });
            }
            res.json({ message: 'Admin details updated successfully!' });
        }
    );

});


// Register Need-Based Scholarship
app.post('/register-needbased', upload.single('financialDocuments'), (req, res) => {
    const { name, studentId, householdIncome } = req.body;
    const financialDocuments = req.file ? req.file.filename : null;
    const dependents = JSON.parse(req.body.dependents || '[]');

    if (!name || !studentId || !householdIncome || !financialDocuments) {
        return res.status(400).json({ message: 'All fields are required.' });
    }

    const insertScholarshipQuery = `
        INSERT INTO needbasedscholarship (name, student_id, household_income, financial_documents)
        VALUES (?, ?, ?, ?)
    `;

    const insertDependentsQuery = `
        INSERT INTO dependentsneedbasedscholarship (student_id, name, relationship, age, occupation)
        VALUES (?, ?, ?, ?, ?)
    `;

    db.run(insertScholarshipQuery, [name, studentId, householdIncome, financialDocuments], function (err) {
        if (err) {
            console.error('Error inserting scholarship data:', err.message);
            return res.status(500).json({ message: 'Failed to register user.' });
        }

        const stmt = db.prepare(insertDependentsQuery);
        for (const dependent of dependents) {
            stmt.run([studentId, dependent.name, dependent.relationship, dependent.age, dependent.occupation], (err) => {
                if (err) {
                    console.error('Error inserting dependent:', err.message);
                }
            });
        }
        stmt.finalize();

        res.json({ message: 'Need-Based Scholarship Registered successfully!' });
    });
});

// Register Merit Scholarship
app.post('/register-merit', upload.single('academicRecord'), (req, res) => {
    const { name, studentId, program, achievements } = req.body;
    const academicRecord = req.file ? req.file.filename : null;

    if (!name || !studentId || !program || !achievements || !academicRecord) {
        return res.status(400).json({ message: 'All fields are required.' });
    }

    const query = `
        INSERT INTO meritscholarship (name, student_id, program, achievements, academic_record)
        VALUES (?, ?, ?, ?, ?)
    `;

    db.run(query, [name, studentId, program, achievements, academicRecord], function (err) {
        if (err) {
            console.error('Error inserting merit scholarship data:', err.message);
            return res.status(500).json({ message: 'Failed to register merit scholarship.' });
        }
        res.json({ message: 'Merit Scholarship Registered successfully!' });
    });
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

// Handle Appeal Decision submission
app.post('/submit-appeal', upload.single('appealDocs'), (req, res) => {
    const { name, studentId, aidType, reasonRejection, reasonAppeal } = req.body;
    const appealDocs = req.file ? req.file.filename : null;

    if (!name || !studentId || !aidType || !reasonRejection || !reasonAppeal || !appealDocs) {
        return res.status(400).json({ message: 'All fields are required.' });
    }

    const query = `
        INSERT INTO appeal_decision (name, student_id, aid_type, reason_rejection, reason_appeal, appeal_docs, status)
        VALUES (?, ?, ?, ?, ?, ?, 'pending')
    `;

    db.run(query, [name, studentId, aidType, reasonRejection, reasonAppeal, appealDocs], function (err) {
        if (err) {
            console.error('Error inserting appeal decision:', err.message);
            return res.status(500).json({ message: 'Database error.' });
        }
        res.json({ message: 'Appeal submitted successfully!' });
    });
});

// Fetch Merit-Based Scholarships
app.get('/get-merit-scholarships', (req, res) => {
    const query = 'SELECT * FROM meritscholarship';
    db.all(query, [], (err, rows) => {
        if (err) {
            return res.status(500).json({ message: 'Database error.' });
        }
        res.json(rows);
    });
});

// Fetch Need-Based Scholarships
app.get('/get-needbased-scholarships', (req, res) => {
    const query = 'SELECT * FROM needbasedscholarship';
    db.all(query, [], (err, rows) => {
        if (err) {
            return res.status(500).json({ message: 'Database error.' });
        }
        res.json(rows);
    });
});

// Fetch Dependents for a Need-Based Scholarship
app.get('/get-dependents/:studentId', (req, res) => {
    const { studentId } = req.params;

    const query = `SELECT * FROM dependentsneedbasedscholarship WHERE student_id = ?`;
    db.all(query, [studentId], (err, rows) => {
        if (err) {
            return res.status(500).json({ message: 'Database error.', error: err.message });
        }
        res.json(rows);
    });
});

app.get('/get-all-dependents', (req, res) => {
    const query = `SELECT * FROM dependentsneedbasedscholarship`;

    db.all(query, [], (err, rows) => {
        if (err) {
            return res.status(500).json({ message: 'Database error.', error: err.message });
        }
        res.json(rows);
    });
});



app.get('/uploads/:file', (req, res) => {
    console.log(`Requesting file: ${req.params.file}`);
    res.sendFile(path.join(__dirname, 'uploads', req.params.file));
});


// Fetch Appeals

app.get('/get-appeals', (req, res) => {
    const query = 'SELECT * FROM appeal_decision';
    db.all(query, [], (err, rows) => {
        if (err) {
            return res.status(500).json({ message: 'Database error.', error: err.message });
        }
        res.json(rows);
    });
});


// Update Scholarship Status
app.post('/update-status', (req, res) => {
    const { id, status, type } = req.body;

    let query;
    if (type === "merit") {
        query = `UPDATE meritscholarship SET status = ? WHERE id = ?`;
    } else if (type === "needbased") {
        query = `UPDATE needbasedscholarship SET status = ? WHERE id = ?`;
    } else {
        return res.status(400).json({ message: 'Invalid scholarship type' });
    }

    db.run(query, [status, id], function (err) {
        if (err) {
            console.error('Error updating status:', err.message);
            return res.status(500).json({ message: 'Database error' });
        }

        console.log(`Status updated for ID ${id}`);

        // Manually populate accepted students after update
        manuallyPopulateAcceptedStudents();

        res.json({ message: 'Status updated successfully' });
    });
});





// Update appeal decision status
app.post('/update-appeal-status', (req, res) => {
    const { id, status } = req.body;

    if (!id || !status) {
        return res.status(400).json({ message: 'Appeal ID and status are required.' });
    }

    const query = `UPDATE appeal_decision SET status = ? WHERE id = ?`;
    db.run(query, [status, id], function (err) {
        if (err) {
            console.error('Error updating appeal status:', err.message);
            return res.status(500).json({ message: 'Database error' });
        }

        console.log(`Appeal status updated for ID ${id}`);

        // Manually populate accepted students after update
        manuallyPopulateAcceptedStudents();

        res.json({ message: 'Appeal status updated successfully!' });
    });
});


// Update accepted_students table
function manuallyPopulateAcceptedStudents() {
    // Clear existing entries to avoid duplicates
    const deleteQuery = `DELETE FROM accepted__students`;
    db.run(deleteQuery, function (err) {
        if (err) {
            console.error('Error clearing accepted__students:', err.message);
            return;
        }

        console.log('Cleared accepted__students table.');

        // Fetch approved students
        const selectQuery = `
            SELECT name, student_id, status, aid_type FROM meritscholarship WHERE status = 'approved'
            UNION ALL
            SELECT name, student_id, status, aid_type FROM needbasedscholarship WHERE status = 'approved'
            UNION ALL
            SELECT name, student_id, status, aid_type FROM appeal_decision WHERE status = 'approved'
        `;

        db.all(selectQuery, [], (err, rows) => {
            if (err) {
                console.error('Error retrieving approved students:', err.message);
                return;
            }

            if (rows.length === 0) {
                console.log('No approved students found.');
                return;
            }

            console.log(`Found ${rows.length} approved students.`);

            // Insert approved students
            const insertQuery = `
                INSERT INTO accepted__students (name, student_id, status, aid_type) 
                VALUES (?, ?, ?, ?)
            `;

            const stmt = db.prepare(insertQuery);
            rows.forEach(row => {
                stmt.run([row.name, row.student_id, row.status, row.aid_type], (err) => {
                    if (err) {
                        console.error('Error inserting into accepted__students:', err.message);
                    }
                });
            });

            stmt.finalize(() => {
                console.log('Accepted students table updated successfully.');
            });
        });
    });
}

app.post('/populate-accepted-students', (req, res) => {
    manuallyPopulateAcceptedStudents();
    res.json({ message: 'Accepted students table is being updated manually.' });
});

// Fetch accepted students data
app.get('/get-accepted-students', (req, res) => {
    const query = `SELECT name, student_id, status, aid_type, aid_amount FROM accepted__students`;

    db.all(query, [], (err, rows) => {
        if (err) {
            return res.status(500).json({ message: 'Database error.', error: err.message });
        }
        res.json(rows);
    });
});


// Update Aid Amount
app.post('/update-aid-amount', (req, res) => {
    const { student_id, aid_amount } = req.body;

    if (!student_id || aid_amount === undefined) {
        return res.status(400).json({ message: 'Student ID and aid amount are required.' });
    }

    const query = `UPDATE accepted__students SET aid_amount = ? WHERE student_id = ?`;

    db.run(query, [aid_amount, student_id], function (err) {
        if (err) {
            console.error('Error updating aid amount:', err.message);
            return res.status(500).json({ message: 'Database error.' });
        }
        res.json({ message: `Aid amount updated successfully for Student ID ${student_id}` });
    });
});

// Get Budget Info
app.get('/get-budget-info', (req, res) => {
    const totalBudget = 100000; // Fixed total budget

    const query = `SELECT SUM(aid_amount) AS totalAllocated FROM accepted__students`;

    db.get(query, [], (err, row) => {
        if (err) {
            return res.status(500).json({ message: 'Database error.', error: err.message });
        }
        const totalAllocated = row.totalAllocated || 0;
        const remainingBudget = totalBudget - totalAllocated;

        res.json({ totalBudget, totalAllocated, remainingBudget });
    });
});

//ChecK Application Status
app.get('/get-application-status/:userId', (req, res) => {
    const { userId } = req.params;

    const query = `
        SELECT student_id, status, aid_type FROM meritscholarship WHERE student_id = ?
        UNION ALL
        SELECT student_id, status, aid_type FROM needbasedscholarship WHERE student_id = ?
        UNION ALL
        SELECT student_id, status, aid_type FROM appeal_decision WHERE student_id = ?
    `;

    db.get(query, [userId, userId, userId], (err, row) => {
        if (err) {
            return res.status(500).json({ message: 'Database error.', error: err.message });
        }
        if (row) {
            res.json({ status: row.status, aid_type: row.aid_type });
        } else {
            res.json({ message: 'No application found.' });
        }
    });
});